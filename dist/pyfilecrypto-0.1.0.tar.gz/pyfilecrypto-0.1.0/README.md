# PyFileCrypto

PyFileCrypto is a Python module for easy encryption and decryption of files using the `cryptography` library. It provides a simple interface to generate encryption keys, encrypt files, and decrypt files securely.

## Installation

You can install PyFileCrypto using pip:

```bash
pip install pyfilecrypto
